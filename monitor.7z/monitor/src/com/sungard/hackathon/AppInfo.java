package com.sungard.hackathon;

import java.io.Serializable;

/**
 * Drtp监控信息
 * 
 * @author Bingjue.Sun
 * 
 */
public class AppInfo implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -597695103530328220L;
	public static final int ONLINE = 0;
	public static final int OFFLINE = 1;

	public static final int CHANGED = 1;// 改变
	public static final int UNCHANGED = 0;// 未改变
	
 
	// clientId
	private String id;
	// 主机ip地址
	private String name;
	// 状态
	private int status= ONLINE;
	
	private String machine;
	
	private String machineIp;
	
	
	public AppInfo(String id, String name, int status, String machine,
			String machineIp) {
		super();
		this.id = id;
		this.name = name;
		this.status = status;
		this.machine = machine;
		this.machineIp = machineIp;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getMachine() {
		return machine;
	}
	public void setMachine(String machine) {
		this.machine = machine;
	}
	public String getMachineIp() {
		return machineIp;
	}
	public void setMachineIp(String machineIp) {
		this.machineIp = machineIp;
	}
}
