package com.sungard.hackathon;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.TaskStackBuilder;
import android.util.Log;

import com.google.gson.Gson;

/**
 * mqtt 信息receiver
 * 
 * @author Bingjue.Sun
 * 
 */
public class AppMonitorReceiver extends BroadcastReceiver {

	private static final int ID = 1;
	private static String MQTT_CONTENT = "mqtt_content";
	private SharedPreferences sp;
	private AppInfo[] viewItems;

	@Override
	public void onReceive(Context context, Intent intent) {
		String content = intent.getStringExtra("mqtt_message");
		Gson gson = new Gson();
		viewItems = gson.fromJson(content, AppInfo[].class);
		Log.d("==========================", "DrtpMonitorReceiver" + "==-=-=-="
				+ content);
		sp = context.getSharedPreferences(MQTT_CONTENT, Context.MODE_PRIVATE);
		Editor editor = sp.edit();
		editor.putString("content", content);
		editor.commit();
		
		Intent intentmain = new Intent(context, MoreAppActivity.class);
		context.startActivity(intentmain);

//		for (int i = 0; i < viewItems.length; i++) {
//			AppInfo dm = viewItems[i];
//			if (dm.getChanged() == 1) {
//				sendNotification(dm.getAppName(),
//						dm.getState() == 0 ? "recovered" : "down" + "", context);
//			}
//		}

	}

	public void sendNotification(String appName, String appState,
			Context context) {
		NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(
				context).setSmallIcon(R.drawable.feed).setContentTitle(appName)
				.setContentText(appState)
				.setVibrate(new long[] { 500L, 200L, 200L, 500L })
				.setLights(0xff00ff00, 300, 1000).setAutoCancel(true);

		NotificationManager mNotificationManager = (NotificationManager) context
				.getSystemService(Context.NOTIFICATION_SERVICE);
		Intent intent = new Intent(context, MoreAppActivity.class);
		TaskStackBuilder stackBuilder = TaskStackBuilder.create(context);
		stackBuilder.addParentStack(MoreAppActivity.class);
		stackBuilder.addNextIntent(intent);
		PendingIntent resultPendingIntent = stackBuilder.getPendingIntent(0,
				PendingIntent.FLAG_UPDATE_CURRENT);
		mBuilder.setContentIntent(resultPendingIntent);
		// 发动通知
		mNotificationManager.notify(ID, mBuilder.build());
	}
}
