package com.sungard.hackathon;


import com.sungard.hackathon.service.ImageService;
import com.sungard.hackathon.service.MqttService;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class DownloadActivity extends Activity {
    private TextView addressET;
    private ImageView imageIV;
    private Handler handler=new Handler(); //在主线程中创建handler
    private ProgressDialog dialog;
    private ImageService service;
    private Context context;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        
        //启动mqtt 、service
        context = this;
		Intent i = new Intent(context, MqttService.class);
		context.startService(i);
		
        
        //1、获取对话框的id
        addressET = (TextView) this.findViewById(R.id.addressET);
        imageIV = (ImageView) this.findViewById(R.id.imageIV);
        
        service = new ImageService(this);
        
    }
    
    public void onClick(View v){
        //把图片放在一个新的线程里面来读取.
        new Thread(){//创建一个新的线程
            public void run(){
                try {
                String address = addressET.getText().toString();
                
                handler.post(new Runnable() {//此处用一个匿名内部类，runnable自动把消息发送给主线程创建处理的handler，主线程会自动更新。
                    public void run() {

                        dialog=new ProgressDialog(DownloadActivity.this);
                        dialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);//设置进度条样式
                        dialog.setMessage("请稍候...");
                        dialog.setCancelable(false);//判断是否取消进度条
                        dialog.show();
                    }
                });
                    
                
                    //由于网络操作比较耗时，所以在新线程中操作
                    final Bitmap image = service.getImage(address);
                    handler.post(new Runnable() {
                        public void run() {
                            dialog.dismiss();
                            imageIV.setImageBitmap(image);//新线程更新界面，需要使用handler
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(), "服务器忙，请稍后再试！", 0).show();
                }
            }
        }.start();
    }
}
