package com.sungard.hackathon;

import n.integration.hackathon.ngbf.NgbfMqttClient;

import com.sungard.hackathon.service.MqttService;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint("HandlerLeak")
public class MainActivity extends Activity implements OnClickListener {

	private TextView name;
	private Button button;
	private ImageButton imageButton;
	private Context context;

	private Handler mHandler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case 1:
				imageButton.setImageDrawable(getResources().getDrawable(R.drawable.rotate_loading1_360));
				break;
			default:
				break;
			}
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		name = (TextView) findViewById(R.id.name);
		imageButton = (ImageButton)findViewById(R.id.imagebtn);
		button = (Button) findViewById(R.id.btn);
		button.setOnClickListener(this);
		//启动mqtt 、service
        context = this;
		Intent i = new Intent(context, MqttService.class);
		context.startService(i);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.btn:
			new Thread(){//创建一个新的线程
	            public void run(){
	            	String fileName = name.getText().toString();
	    			Message ms = new Message();
	    			ms.what = 1;
	    			ms.obj = fileName;
	    			mHandler.sendMessage(ms);
	    			
	    			//
	            }
	        }.start();
			break;
		}
	}

}
