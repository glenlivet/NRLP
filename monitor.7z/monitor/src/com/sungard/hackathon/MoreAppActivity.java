package com.sungard.hackathon;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.sungard.hackathon.service.MqttService;

@SuppressLint("UseSparseArrays")
public class MoreAppActivity extends Activity {
	private ListView rightListView;
	private ListAdapter listAdapter;
	private Context context;
	private SharedPreferences sp;
	private AppReceiver receiver = null;

	private AppInfo[] viewItems;
	
	private  Handler mHandler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case 1:
				viewItems = (AppInfo[]) msg.obj;
				selectDefult(viewItems);
				break;
			default:
				break;
			}

		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_more_app);
		
		/*动态方式注册广播接收者*/
        receiver = new AppReceiver();
        IntentFilter filter = new IntentFilter();
        filter.addAction("mqtt.msgreceived.action");
        this.registerReceiver(receiver, filter);
		
		
		context = this;
		Intent i = new Intent(context, MqttService.class);
		context.startService(i);
		
		
		rightListView = (ListView) findViewById(R.id.listView_right);

		sp = context.getSharedPreferences("mqtt_content", Context.MODE_PRIVATE);
		Gson gson = new Gson();
		String content = sp.getString("content", "");

		if (!content.equals("")) {
			viewItems = gson.fromJson(content, AppInfo[].class);
		} else {
			viewItems = new AppInfo[1];
			viewItems[0] =  new AppInfo("","",0,"","");
		}
		selectDefult(viewItems);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.movies, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.action_search:
			Toast.makeText(this, "搜索未实现", Toast.LENGTH_SHORT).show();
			return true;
		case R.id.action_about:
			Toast.makeText(this, "未实现", Toast.LENGTH_SHORT).show();
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	private void selectDefult(AppInfo[] items) {
		// 默认选中
		listAdapter = new ListAdapter(context, items);
		rightListView.setAdapter(listAdapter);
		rightListView.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1,
					int position, long arg3) {
				// TODO Auto-generated method stub
			}
		});
	}

	@SuppressLint("UseSparseArrays")
	class ListAdapter extends BaseAdapter {

		private Context context;
		private AppInfo[] items;
		private LayoutInflater inflater;

		public ListAdapter(Context context, AppInfo[] items) {
			super();
			this.context = context;
			this.items = items;
			inflater = LayoutInflater.from(context);
		}

		@Override
		public int getCount() {
			return items.length;
		}

		@Override
		public Object getItem(int position) {
			return items[position];
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(final int position, View convertView,
				ViewGroup parent) {
			final ViewHolder holder;
			if (convertView == null) {
				holder = new ViewHolder();
				convertView = inflater.inflate(R.layout.new_item_choose, null);
				holder.imagebutton = (ProgressBar) convertView
						.findViewById(R.id.imagebutton);
				holder.icon = (ImageView) convertView.findViewById(R.id.icon);
				holder.title = (TextView) convertView.findViewById(R.id.title);
				holder.content = (TextView) convertView
						.findViewById(R.id.content);
				convertView.setTag(holder);
			} else {
				holder = (ViewHolder) convertView.getTag();
			}

			// 标题
			holder.title.setText("ID: "+items[position].getId());

			holder.title.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					Toast.makeText(context, items[position].getName(),
							Toast.LENGTH_SHORT).show();
				}
			});

			holder.content.setText("From:"+items[position].getMachineIp());

			// logo
			if(items[position].getName().equals("app")){
				holder.icon.setImageResource(R.drawable.app);
			}
			if(items[position].getName().equals("nodejs")){
				holder.icon.setImageResource(R.drawable.nodejs);
			}
			if(items[position].getName().equals("d-profile")){
				holder.icon.setImageResource(R.drawable.profile);
			}
			 
			if(items[position].getStatus()==1){
				holder.imagebutton.setIndeterminateDrawable(getResources().getDrawable(R.drawable.rotate_loading_360));
			}else{
				holder.imagebutton.setIndeterminateDrawable(getResources().getDrawable(R.drawable.rotate_loading1_360));
			}
			return convertView;
		}

	}

	public static class ViewHolder {
		private ProgressBar imagebutton;
		private TextView title, content;
//		private ImageButton imagebutton;
		private ImageView icon;
	}
	
	
	class AppReceiver extends BroadcastReceiver{

		private static final int ID = 1;
		private static final String MQTT_CONTENT = "mqtt_content";
		private SharedPreferences sp;
		private AppInfo[] viewItems;
		
		public AppReceiver(){
			
		}

		@Override
		public void onReceive(Context context, Intent intent) {
			String content = intent.getStringExtra("mqtt_message");
			Gson gson = new Gson();
			viewItems = gson.fromJson(content, AppInfo[].class);
			Log.d("==========================", "DrtpMonitorReceiver" + "==-=-=-="
					+ content);
			sp = context.getSharedPreferences(MQTT_CONTENT, Context.MODE_PRIVATE);
			Editor editor = sp.edit();
			editor.putString("content", content);
			editor.commit();
			Message ms = new Message();
			ms.what = 1;
			ms.obj = viewItems;
			mHandler.sendMessage(ms);
		}
		
	}

}
