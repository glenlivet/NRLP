package com.sungard.hackathon.service;


import java.io.File;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import android.accounts.NetworkErrorException;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;

import com.sungard.hackathon.Util;

public class ImageService {

    private Context context;

    public ImageService(Context context) {
        super();
        this.context = context;
    }

    public Bitmap getImage(String address) throws Exception {
        // 1.通过Url对象封装url对象
        URL url = new URL(address);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setReadTimeout(3000);

        // 2.判断是否有缓存文件
        File cacheFile = new File(context.getCacheDir(),
                URLEncoder.encode(address));// 缓存文件
        if (cacheFile.exists())// 判断是否有缓存
            conn.setIfModifiedSince(cacheFile.lastModified());// 发送缓存文件的最后修改时间

        // 3.获取状态码，根据状态吗来判断接下来的操作。读取文件？还是写缓存，写缓存的时候记着用多个线程
        int code = conn.getResponseCode();
        if (code == 200) {
            byte[] data = Util.read(conn.getInputStream());
            Bitmap bm = BitmapFactory.decodeByteArray(data, 0, data.length);// 转化为图片
            weiteCache(cacheFile, bm);
            return bm;
        } else if(code==304){
            return BitmapFactory.decodeFile(cacheFile.getAbsolutePath());//读取本地数据，并转为图片来显示
        }
        
//        如果不成功，抛异常，给我们自己看的
        throw new NetworkErrorException("访问服务器出错："+code);
        

    }

    // 4. 写缓存文件
    private void weiteCache(final File cacheFile, final Bitmap bm) {
        // 使用一个新的线程来写，这样的好处就是在页面打开的时候不会因为写缓存而等待时间
        new Thread() {
            public void run() {
                try {
                    FileOutputStream fos = new FileOutputStream(cacheFile);
                    bm.compress(CompressFormat.JPEG, 100, fos);//指定格式 存储到本地
                    fos.close();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }

            }
        }.start();

    }

}