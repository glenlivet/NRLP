package com.sungard.hackathon.service;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import n.integration.hackathon.ngbf.ConnectionLostEvent;
import n.integration.hackathon.ngbf.IMqttEventListener;
import n.integration.hackathon.ngbf.MessageArrivedEvent;
import n.integration.hackathon.ngbf.MqttParams;
import n.integration.hackathon.ngbf.NgbfMqttClient;
import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.telephony.TelephonyManager;
import android.util.Log;

/**
 * 
 * connect to mqtt broker, listen to message arrived event.
 * 
 * @author bingjue.sun
 * 
 */
public class MqttService extends Service {
	public static final String MQTT_MSG_ACTION = "mqtt.msgreceived.action";
	private static final String BROKER_URL = "tcp://10.253.44.235:1883";
	private static final String MQTT_DIR = "mqttdata";
	private static final String MONITOR_TOPIC = "monitor/apps";
	private static final int RECONNECT_INTERVAL = 30000;
	private static final String TAG = "MqttService";

	public static NgbfMqttClient mqttClient;
	
	WakeLock wakeLock = null;

	@Override
	public IBinder onBind(Intent arg0) {
		return null;
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		// 获取wakeLock
		// 如果未连接 执行连接
		// 释放wakeLock
		requireWakeLock();
		Log.d(TAG, "MqttService Start!");
		if (!mqttClient.isAvailable() && isWifiEnabled()) {
			doMqttConnect(true);
		}
		releaseWakeLock();
		return Service.START_STICKY;
	}

	private void releaseWakeLock() {
		if (wakeLock != null) {
			wakeLock.release();
		}
	}

	private void requireWakeLock() {
		PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
		wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
				"MqttWakelockTag");
		wakeLock.acquire();
	}

	/**
	 * 是否在WIFI环境下
	 * 
	 * @return
	 */
	private boolean isWifiEnabled() {
		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
		if (activeNetwork == null) {
			return false;
		} else {
			int type = activeNetwork.getType();
			if (type == ConnectivityManager.TYPE_WIFI) {
				return true;
			}
			return false;
		}
	}

	private void doMqttConnect() {
		doMqttConnect(false);
	}

	/**
	 * 连接MQTT BROKER
	 */
	private void doMqttConnect(boolean block) {

		Thread t = new Thread(new Runnable() {

			@Override
			public void run() {
				// 检查mqttClient是否可用
				// 不可用 开始连接
				// 连接失败 检查网络是否为WIFI
				// 不是则返回】
				// 是 则过一段时间后重连
				boolean success;
				do {
					if (!mqttClient.isAvailable()) {
						success = mqttClient.connect();
					} else {
						return;
					}

					if (success) {
						Log.d(TAG, "连接成功！");
						return;
					}
					try {
						Log.d(TAG, "连接失败" + RECONNECT_INTERVAL / 1000 + "秒后重连。");
						Thread.sleep(RECONNECT_INTERVAL);
						if (!isWifiEnabled()) {
							stopSelf();
							return;
						}
					} catch (InterruptedException e) {
					}
				} while (!success);
			}

		});
		t.start();
		if (block) {
			try {
				t.join();
			} catch (InterruptedException e) {
			}
		}
	}

	@Override
	public void onCreate() {
		Log.d(TAG, "MqttService onCreate!");
		// 实例化MQTT CLIENT
		initMqttClient();
		super.onCreate();
	}

	/**
	 * 实例化MQTT client
	 */
	private void initMqttClient() {
		// mqtt参数设置
		TelephonyManager tm = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
		@SuppressWarnings("unused")
		String clientId = getUniqueId(tm);
		MqttParams params = new MqttParams(BROKER_URL, "jkljkljlj",
				new String[] { MONITOR_TOPIC},
				new int[] {2});
		params.setCleanSession(false);
		params.setDataUrl(getDataUrl());

		mqttClient = new NgbfMqttClient(params, new MobileMqttListener());

	}

	/**
	 * mqtt持久化地址
	 * 
	 * @return
	 */
	private String getDataUrl() {
		File dir = getDir(MQTT_DIR, MODE_PRIVATE);
		Log.d(TAG, dir.getAbsolutePath());
		return dir.getAbsolutePath();
	}

	@Override
	public void onDestroy() {
		mqttClient.disconnect();
		super.onDestroy();
	}

	/**
	 * 获取设备信息唯一ID
	 * 
	 * @param tm
	 * @return
	 */
	public static String getUniqueId(TelephonyManager tm) {
		String uniqueId = "";
		if (tm != null) {
			uniqueId = tm.getDeviceId();
			if (uniqueId == null) {
				// No 3G Model,可能为null?
				uniqueId = tm.getLine1Number();
			}
		}
		return uniqueId;
	}

	@SuppressLint("SimpleDateFormat")
	class MobileMqttListener implements IMqttEventListener {

		@Override
		public void onConnectionLost(ConnectionLostEvent event) {
			// 是否为WIFI
			// 是 重连 不是 结束服务
			Log.d(TAG, "失去连接");
			if (!isWifiEnabled()) {
				Log.d(TAG, "WIFI不可用-=-=-=-=-=-=-=-=-=");
				stopSelf();
				return;
			}
			doMqttConnect();
		}

		@Override
		public void onMessageArrived(MessageArrivedEvent event) {
			SimpleDateFormat sd = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date1 = new Date();
			String str1 = sd.format(date1);
			System.out.println("msg receive time======================------------================" + str1);

			Log.d(TAG, "mqtt msg received1!");
			Log.d(TAG, "mqtt content1: " + event.getMessage());
			if (event.getTopic().equalsIgnoreCase(MONITOR_TOPIC)) {
				//如果是DRTP
				Intent intent = new Intent();
				intent.putExtra("mqtt_topic", event.getTopic());
				intent.putExtra("mqtt_message", event.getMessage());
				intent.setAction(MQTT_MSG_ACTION);
				sendBroadcast(intent);
			}
		}
	}
	
	public  NgbfMqttClient getMqttClient(){
		if(mqttClient==null){
			initMqttClient();
		}
		return mqttClient;
	}
	 
}
