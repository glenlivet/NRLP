package com.sungard.hackathon.service;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;

/**
 * broadcast receiver for network changing.
 * 
 * @author bingjue.sun
 *
 */
public class NetInfoBroadcastReceiver extends BroadcastReceiver {

	public static final String TAG = "MqttService";

	@Override
	public void onReceive(Context context, Intent intent) {
		Intent i = new Intent(context, MqttService.class);
		Log.d(TAG, "Network changed!");
		ConnectivityManager cm = (ConnectivityManager) context
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
		
		if (activeNetwork == null) {
			context.stopService(i);
			return;
		} else {
			Log.d(TAG, "NetWork state: " + activeNetwork.getTypeName());
			int type = activeNetwork.getType();
			if(type == ConnectivityManager.TYPE_WIFI){
				context.startService(i);
			}
		}
	}
}
