/**
 * 
 */
package com.sungard.hackathon.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import org.apache.http.HttpVersion;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.impl.client.AbstractHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpProtocolParams;
import org.apache.http.protocol.HTTP;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

/**
 * 
 * @author bingjue.sun
 * 
 */
public class HttpUtils {

	private final static int HTTP_REQUEST_ERROR = 400;

	private final static int HTTP_RESPONSE = 0x1;

	private final static int REQUEST_TIMEOUT = 10000;

	private final static int SO_TIMEOUT = 10000;

	@SuppressWarnings("unused")
	private final static int HTTP_SERVER_ERROR = 404;

	/* 线程池 */
	private static final Executor executor = Executors.newFixedThreadPool(5);

	private static AbstractHttpClient client;

	private final static Handler handler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case HTTP_RESPONSE:
				HttpListener httpListener = (HttpListener) msg.obj;
				Bundle bundle = msg.getData();
				int status = bundle.getInt("status");
				String response = bundle.getString("response");
				httpListener.callBack(response, status);
				break;
			default:

				break;
			}

			super.handleMessage(msg);
		}
	};

	public static void doGet(final String uri, final HttpListener httpListener) {
		executor.execute(new Runnable() {

			@Override
			public void run() {
				 Message msg = new Message();
				 msg.what = HTTP_RESPONSE;
				 msg.obj = httpListener;
				 Bundle data = new Bundle();
				URL url = null;
				HttpURLConnection conn = null;
				try {
					url = new URL(uri);
					conn = (HttpURLConnection) url.openConnection();
					conn.setRequestMethod("GET");
					conn.setDoOutput(true);
					conn.setDoInput(true);
					conn.setUseCaches(false);
					conn.setRequestProperty("Content-Type",
							"application/x-www-form-urlencoded");
					conn.connect();
					// 读取返回内容
					StringBuffer buffer = new StringBuffer();
					BufferedReader br = new BufferedReader(
							new InputStreamReader(conn.getInputStream(),
									HTTP.UTF_8));
					String temp;
					while ((temp = br.readLine()) != null) {
						buffer.append(temp);
						buffer.append("\n");
					}
					data.putString("response", buffer.toString());
					// data.putString("response", conn.getResponseMessage());
					data.putInt("status", conn.getResponseCode());
					msg.setData(data);
//					handler.sendMessage(msg);
				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				} catch (ClientProtocolException e) {
					e.printStackTrace();
				} catch (ParseException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				} finally {
					if (conn != null) {
						conn.disconnect();
					}
				}

			}
		});
	}

	public static void doGet(final String uri, final HttpListener httpListener,
			String json) {
		executor.execute(new Runnable() {

			@Override
			public void run() {
				Message msg = new Message();
				msg.what = HTTP_RESPONSE;
				msg.obj = httpListener;
				Bundle data = new Bundle();
				URL url = null;
				HttpURLConnection conn = null;
				try {
					url = new URL(uri);
					conn = (HttpURLConnection) url.openConnection();
					conn.setRequestMethod("GET");
					conn.setDoOutput(true);
					conn.setDoInput(true);
					conn.setUseCaches(false);
					/*
					 * conn.setRequestProperty("Content-Type",
					 * "application/x-www-form-urlencoded");
					 */
					conn.setRequestProperty("X-RequestEntity-ContentType ",
							"application/json");
					conn.connect();
					// 读取返回内容
					StringBuffer buffer = new StringBuffer();
					BufferedReader br = new BufferedReader(
							new InputStreamReader(conn.getInputStream(),
									HTTP.UTF_8));
					String temp;
					while ((temp = br.readLine()) != null) {
						buffer.append(temp);
						buffer.append("\n");
					}
					data.putString("response", buffer.toString());
					// data.putString("response", conn.getResponseMessage());
					data.putInt("status", conn.getResponseCode());
					msg.setData(data);
					handler.sendMessage(msg);
				} catch (UnsupportedEncodingException e) {
					data.putInt("status", HTTP_REQUEST_ERROR);
					data.putString("response", "请求错误：不支持的数据编码");
					e.printStackTrace();
				} catch (ClientProtocolException e) {
					data.putInt("status", HTTP_REQUEST_ERROR);
					data.putString("response", "请求错误：请求协议错误");
					e.printStackTrace();
				} catch (ParseException e) {
					data.putInt("status", HTTP_REQUEST_ERROR);
					data.putString("response", "请求错误：解析错误");
					e.printStackTrace();
				} catch (IOException e) {
					data.putInt("status", HTTP_REQUEST_ERROR);
					data.putString("response", "请求错误：IOException");
					e.printStackTrace();
				} finally {
					if (conn != null) {
						conn.disconnect();
					}
				}

			}
		});
	}

	public static HttpClient getHttpClient() {
		if (client == null) {
			BasicHttpParams httpParams = new BasicHttpParams();
			HttpConnectionParams.setConnectionTimeout(httpParams,
					REQUEST_TIMEOUT);
			HttpConnectionParams.setSoTimeout(httpParams, SO_TIMEOUT);
			HttpProtocolParams.setVersion(httpParams, HttpVersion.HTTP_1_1);
			HttpProtocolParams.setContentCharset(httpParams, HTTP.UTF_8);
			HttpProtocolParams.setUseExpectContinue(httpParams, true);

			SchemeRegistry schReg = new SchemeRegistry();
			schReg.register(new Scheme("http", PlainSocketFactory
					.getSocketFactory(), 80));
			schReg.register(new Scheme("https", PlainSocketFactory
					.getSocketFactory(), 433));
			ClientConnectionManager conMgr = new ThreadSafeClientConnManager(
					httpParams, schReg);
			client = new DefaultHttpClient(conMgr, httpParams);
		}
		return client;
	}

	public interface HttpListener {

		public void callBack(String responseBody, int status);

	}

	public static void main(String[] args) {
		String url = "http://10.253.45.103:8087/mini/cxf/ngbf/c/mobile/versionCheck/{\"body\":{},\"head\":{\"api_version\":\"0.1\",\"api_author\":\"NGBF\",\"api_name\":\"versionCheck\",\"msg_encrypt\":\"0\",\"rep_code\":\"\",\"rep_message\":\"\"}}";
		HttpUtils.doGet(url, new HttpUtils.HttpListener() {
			@Override
			public void callBack(String responseBody, int status) {
				System.out.println("responseBody=" + responseBody + ",status="
						+ status);
			}
		});
	}

}
